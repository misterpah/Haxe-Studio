function cpuTime()
{
return new Date().getTime();
}
